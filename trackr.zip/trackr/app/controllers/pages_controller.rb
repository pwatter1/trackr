class PagesController < ApplicationController
    def index
        #render template: "pages/#{params[:page]}"
    end
    
end
