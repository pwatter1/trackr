class GoalsController < ApplicationController
    # used this page as an example
    # https://github.com/tjh/Basic-Rails-CRUD/blob/master/app/controllers/posts_controller.rb
    
    # list all goals
    def index 
        @goals = Goal.find(1)
    end
    
    def new
        @goals = Goal.find(1)
        @goals.update_attributes!(params[:goal])
        puts params[:goal]
        #@goals.goal = 10;
        #@goals.save!
    end
    
    def create
        redirect_to goals_path
    end
    
    def edit
        @goal = Goal.find(1)
    end

    def update
        @goal = Goal.find(1)
        @goal.update_attributes!(params[:goal])
        flash[:notice] = "#{@goal.id} was successfully updated."
        redirect_to movie_path(@goal)
    end

    def destroy
    end
end