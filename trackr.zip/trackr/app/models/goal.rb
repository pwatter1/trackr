class Goal < ActiveRecord::Base
end
